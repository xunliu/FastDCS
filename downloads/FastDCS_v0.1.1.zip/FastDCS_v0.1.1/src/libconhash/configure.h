#ifndef LIBCONHASH_CONFIGURE_H_
#define LIBCONHASH_CONFIGURE_H_

typedef unsigned int u_int;
typedef unsigned char u_char;
typedef long util_long;

#endif // LIBCONHASH_CONFIGURE_H_
